let a = prompt("Informe um número: ");
let b = prompt("Informe outro número: ");

a = parseFloat(a);
b = parseFloat(b);

let resultado = a + b;

console.log("A soma é igual a: " + resultado);