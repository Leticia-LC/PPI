let a = prompt("Informe um número: ");

for(let i = 0; i < a; i++){
    console.log(i);
}